package employer.employee.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import employer.employee.model.Employee;
import employer.employee.repository.EmployeeRepository;

@Service
public class EmployeeDao {
	
	@Autowired
	private EmployeeRepository empRepo;
	
	public List<Employee> addEmployee(Employee emp){
		empRepo.save(emp);
		return empRepo.findAll();
	}
	
	public List<Employee> getEmployeeList(){
		return empRepo.findAll(Sort.by(Sort.Direction.DESC,"salary"));
	}

}
